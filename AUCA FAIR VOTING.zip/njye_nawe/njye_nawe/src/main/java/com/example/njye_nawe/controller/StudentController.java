package com.example.njye_nawe.controller;

import com.example.njye_nawe.model.Student;
import com.example.njye_nawe.services.implementation.StudentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class StudentController {

    @Autowired
    StudentServiceImpl studentService;
@GetMapping("/candi")
    public String h(){
        return "package";
    }
    @GetMapping("/ten")
    public String f()
    {
        return "temp";
    }
    @GetMapping("/home")
    public String homePage(Model model){

        model.addAttribute("home",studentService.studentList());

        return "home-page";
    }
@GetMapping("/inde")
    public String ind(){
        return "index";
    }
    @GetMapping("/registration")
    public String registerStudentPage(Model model){
        Student stud = new Student();
        model.addAttribute("student", stud);
        return "registrar";
    }
    @GetMapping("/student-page")
    public String studentpage(Model model){
        Student stud = new Student();
        model.addAttribute("student", stud);
        return "student";
    }

    @PostMapping("/registerVoter1")
    public String reg1one(@ModelAttribute("student") Student theStudent){
        Student savedStudent = studentService.registerStudent(theStudent);
        if(savedStudent != null){
            return "redirect:/student-page?success";
        }
        return "redirect:/student-page?success?error";
    }


    @PostMapping("/registerVoter2")
    public String regTwo(@ModelAttribute("student") Student theStudent){
        Student savedStudent = studentService.registerStudent(theStudent);
        if(savedStudent != null){
            return "redirect:/registration?success";
        }
        return "redirect:/registration?error";
    }
    @GetMapping("/home/update/{id}")
    public String editStudent(@PathVariable String id, Model model){
        model.addAttribute("student", studentService.findStudentByStudentId(id));
        return "update";
    }
      @PostMapping("/home/{id}")
    public String updateStudent(@PathVariable String id,
                                @ModelAttribute("student") Student student, Model model)
      {
          Student existingStudent=studentService.findStudentByStudentId(id);
          existingStudent.setTel(student.getTel());
          existingStudent.setId(student.getId());
          existingStudent.setName(student.getName());
          existingStudent.setEmail(student.getEmail());
          existingStudent.setDpt(student.getDpt());
          studentService.updateStudent(existingStudent);
           return "redirect:/home";
      }
 @GetMapping("/home/{id}")
    public String deleteStudent(@PathVariable String id)
 {
     studentService.deleteStudent(id);
     return "redirect:/home";
 }
 @GetMapping("/sear")
 public String search(Model model)
 {
     Student student=new Student();
     model.addAttribute("search",student);

     return "search";
 }
 @PostMapping("/sear")
 public String searchh(@ModelAttribute("search") Student student, Model model)
 {
     Student student1=studentService.findStudentByStudentId(student.getId());
     if (student1!=null){
         model.addAttribute("student1",student1);
         return "search";
     }
     else {
         model.addAttribute("error","results not found ");
         return "search";
     }

 }
}
