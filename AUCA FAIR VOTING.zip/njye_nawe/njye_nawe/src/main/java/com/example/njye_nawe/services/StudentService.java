package com.example.njye_nawe.services;



import com.example.njye_nawe.model.Student;

import java.util.List;

public interface StudentService {
    // method signature
    // return value , method name;
    Student registerStudent(Student stud);
    Student updateStudent(Student stud);
    void deleteStudent(String stud);
    List<Student> studentList();
    Student findStudentByStudentId(String stud);
}
